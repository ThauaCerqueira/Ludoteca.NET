﻿using System;

namespace Projeto_Ludoteca;

using static Utilitarios;

public class Program
{
    public static void Main(string[] args)
    {
        MenuConsole.Menu();
    }
}